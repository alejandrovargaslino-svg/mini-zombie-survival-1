MINI ZOMBIE SURVIVAL - proyecto Android de prueba

Este proyecto contiene un juego sencillo que se ejecuta dentro de una app Android.
Todavía NO incluye multijugador online ni anuncios. Primero hay que compilar y probar el APK.

Para compilar en GitHub Actions:
1. Sube el contenido de este proyecto a un repositorio de GitHub.
2. Añade el archivo .github/workflows/build-apk.yml indicado en las instrucciones del chat.
3. Ejecuta Actions y descarga el artefacto app-debug-apk.
