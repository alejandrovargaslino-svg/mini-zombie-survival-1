plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.minizombie"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.minizombie"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
    }
}
